function savePlayerGender (sexe){
    localStorage.setItem("gender", sexe);
}

function getPlayerGender(){
    var gender ;
    if (localStorage.getItem("gender") === null) {
        gender = 0 ;
    }

    else {
        gender = parseInt(localStorage.getItem("gender"));
    }
    unityInstance.SendMessage('Main','getPlayerGender',gender);
}