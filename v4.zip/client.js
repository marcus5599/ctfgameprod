function connectToSocket() {

    // Connect to The WSS Server //////////////////////////////////////////////////////
    payload = localStorage.getItem('io_token')+";"+localStorage.getItem('gender');
    //console.log(payload);
    socket = io("https://nanopotableprofessional--five-nine.repl.co/",{query: "token="+payload}) ;

    // Call Unity Function /////////////////////////
    unityInstance = UnityLoader.instantiate("unityContainer", "Build/webgl11.json");
    var execInUnity = function (method) { 
        var args = Array .prototype.slice.call ( arguments , 1);    
        unityInstance.SendMessage ( 'Network Player Manager' , method, args.join ( ',' ));
    } ;


    // Event Handlers /////////////////////////////////////
    this.socket.on( 'connect', function () {
        console.log( 'Connected To Server' );

    } );


    this.socket.on('disconnect', (reason) => {
        if (reason === 'transport close') {
        // the disconnection was initiated by the server, you need to reconnect manually
            execInUnity ('PopUpError',1);
            console.log("Un-Autorized Client")
            socket.destroy();
    }
    // else the socket will automatically try to reconnect
    });

      this.socket.on('destory', (name,) => {
         execInUnity ( 'destoryPlayer' , name);
    });

     this.socket.on('m', (name,posX,posZ) => {
         execInUnity ( 'M' , name, x, z);
    });

     this.socket.on('playerConnect', (playerData) => {
        console.log( 'A Player is Connected ' );
        execInUnity ( 'playerConnect' ,playerData.name, playerData.teamName, playerData.teamColor,playerData.gender, playerData.x, playerData.z);
    })


     this.socket.on('duplicate', (error) => {
        execInUnity ('PopUpError',2);
        console.log( 'You are already Connected' );
        socket.destroy();
    });

    this.socket.on('connect_error', (error) => {
        execInUnity ('PopUpError',3);
        console.log( 'Connexion error' );
    });

    this.socket.on('error', (error) => {
        execInUnity ('PopUpError',4);
        console.log(error);
    });

}


